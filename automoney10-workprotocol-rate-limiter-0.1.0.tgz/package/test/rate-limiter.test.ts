import assert from "node:assert/strict";
import type { AddressInfo } from "node:net";
import { describe, test } from "node:test";

import express from "express";
import { Hono } from "hono";

import {
  MemoryStore,
  RedisStore,
  createExpressRateLimiter,
  createHonoRateLimiter,
  createRateLimiterCore,
  defaultKeyGenerator,
  resolveRule,
} from "../src/index.js";

describe("rate limiter core", () => {
  test("uses the default 100 requests per minute rule", async () => {
    let now = 1_000;
    const limiter = createRateLimiterCore({ now: () => now });
    const result = await limiter.check({ ip: "1.2.3.4", path: "/" });

    assert.equal(result.allowed, true);
    assert.equal(result.limit, 100);
    assert.equal(result.remaining, 99);
    assert.equal(result.headers["X-RateLimit-Limit"], "100");
    now += 1;
  });

  test("fixed window blocks after the configured limit", async () => {
    const limiter = createRateLimiterCore({ limit: 2, windowMs: 1000, now: () => 10_000 });

    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
    const blocked = await limiter.check({ ip: "a" });

    assert.equal(blocked.allowed, false);
    assert.equal(blocked.headers["Retry-After"], "1");
  });

  test("fixed window resets after the window expires", async () => {
    let now = 10_000;
    const limiter = createRateLimiterCore({ limit: 1, windowMs: 1000, now: () => now });

    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
    assert.equal((await limiter.check({ ip: "a" })).allowed, false);
    now += 1_001;

    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
  });

  test("sliding window removes expired hits", async () => {
    let now = 10_000;
    const limiter = createRateLimiterCore({ limit: 2, windowMs: 1000, strategy: "sliding-window", now: () => now });

    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
    now += 500;
    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
    assert.equal((await limiter.check({ ip: "a" })).allowed, false);
    now += 501;

    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
  });

  test("token bucket refills over time", async () => {
    let now = 10_000;
    const limiter = createRateLimiterCore({
      strategy: "token-bucket",
      capacity: 2,
      refillRatePerSecond: 1,
      windowMs: 10_000,
      now: () => now,
    });

    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
    assert.equal((await limiter.check({ ip: "a" })).allowed, false);
    now += 1_000;

    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
  });

  test("separates clients by key", async () => {
    const limiter = createRateLimiterCore({ limit: 1, windowMs: 1000, now: () => 1_000 });

    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
    assert.equal((await limiter.check({ ip: "b" })).allowed, true);
    assert.equal((await limiter.check({ ip: "a" })).allowed, false);
  });

  test("uses x-forwarded-for before request ip", () => {
    const key = defaultKeyGenerator({
      ip: "10.0.0.1",
      headers: { "x-forwarded-for": "203.0.113.10, 10.0.0.2" },
    });

    assert.equal(key, "203.0.113.10");
  });

  test("applies per-route overrides", () => {
    const rule = resolveRule(
      {
        limit: 100,
        routes: [{ path: "/admin", limit: 5, strategy: "sliding-window" }],
      },
      { path: "/admin/users" },
    );

    assert.equal(rule.limit, 5);
    assert.equal(rule.strategy, "sliding-window");
  });

  test("supports regexp route overrides", () => {
    const rule = resolveRule(
      {
        limit: 100,
        routes: [{ path: /^\/api\/v2/, limit: 7 }],
      },
      { path: "/api/v2/users" },
    );

    assert.equal(rule.limit, 7);
  });

  test("supports predicate route overrides", () => {
    const rule = resolveRule(
      {
        limit: 100,
        routes: [{ path: (request) => request.method === "POST", limit: 3 }],
      },
      { method: "POST", path: "/submit" },
    );

    assert.equal(rule.limit, 3);
  });
});

describe("stores", () => {
  test("memory store expires entries", async () => {
    let now = 0;
    const store = new MemoryStore(() => now);

    await store.set("k", { value: 1 }, 100);
    assert.deepEqual(await store.get("k"), { value: 1 });
    now = 101;

    assert.equal(await store.get("k"), undefined);
  });

  test("redis store serializes values with px ttl", async () => {
    const calls: unknown[][] = [];
    const backing = new Map<string, string>();
    const store = new RedisStore({
      get: (key) => backing.get(key) ?? null,
      set: (key, value, mode, ttl) => {
        calls.push([key, value, mode, ttl]);
        backing.set(key, value);
      },
    });

    await store.set("k", { count: 1 }, 250);
    assert.deepEqual(await store.get("k"), { count: 1 });
    assert.equal(calls[0]?.[2], "PX");
    assert.equal(calls[0]?.[3], 250);
  });

  test("redis option auto-selects redis store", async () => {
    const calls: unknown[][] = [];
    const redis = {
      get: () => null,
      set: (key: string, value: string, mode: "PX", ttl: number) => {
        calls.push([key, value, mode, ttl]);
      },
    };
    const limiter = createRateLimiterCore({ redis, limit: 1 });

    assert.equal((await limiter.check({ ip: "a" })).allowed, true);
    assert.equal(calls[0]?.[2], "PX");
  });
});

describe("adapters", () => {
  test("express adapter calls next for allowed requests", async () => {
    const middleware = createExpressRateLimiter({ limit: 1, now: () => 1_000 });
    let nextCalled = false;
    const headers: Record<string, string> = {};

    await middleware(
      { ip: "a", path: "/" },
      { setHeader: (name, value) => { headers[name] = value; } },
      () => { nextCalled = true; },
    );

    assert.equal(nextCalled, true);
    assert.equal(headers["X-RateLimit-Remaining"], "0");
  });

  test("express adapter returns 429 for blocked requests", async () => {
    const middleware = createExpressRateLimiter({ limit: 1, now: () => 1_000 });
    const response: { statusCode?: number; body?: unknown; headers: Record<string, string> } = { headers: {} };
    const res = {
      setHeader: (name: string, value: string) => { response.headers[name] = value; },
      status: (code: number) => { response.statusCode = code; return res; },
      json: (body: unknown) => { response.body = body; return body; },
    };

    await middleware({ ip: "a", path: "/" }, res, () => undefined);
    await middleware({ ip: "a", path: "/" }, res, () => undefined);

    assert.equal(response.statusCode, 429);
    assert.equal(response.headers["Retry-After"], "60");
  });

  test("hono adapter calls next for allowed requests", async () => {
    const middleware = createHonoRateLimiter({ limit: 1, now: () => 1_000 });
    let nextCalled = false;
    const headers: Record<string, string> = {};

    await middleware(
      {
        req: { path: "/", method: "GET", header: () => undefined },
        header: (name, value) => { headers[name] = value; },
      },
      async () => { nextCalled = true; },
    );

    assert.equal(nextCalled, true);
    assert.equal(headers["X-RateLimit-Limit"], "1");
  });

  test("hono adapter returns json 429 for blocked requests", async () => {
    const middleware = createHonoRateLimiter({ limit: 1, now: () => 1_000 });
    const statuses: number[] = [];
    const context = {
      req: { path: "/", method: "GET", header: () => "a" },
      header: () => undefined,
      json: (_body: unknown, status?: number) => {
        statuses.push(status ?? 200);
        return { status };
      },
    };

    await middleware(context, async () => undefined);
    await middleware(context, async () => undefined);

    assert.equal(statuses.at(-1), 429);
  });

  test("works in an actual Express app", async () => {
    const app = express();
    app.use(createExpressRateLimiter({ limit: 1, now: () => 1_000 }));
    app.get("/limited", (_req, res) => {
      res.json({ ok: true });
    });
    const server = app.listen(0);
    const port = (server.address() as AddressInfo).port;
    try {
      const first = await fetch(`http://127.0.0.1:${port}/limited`);
      const second = await fetch(`http://127.0.0.1:${port}/limited`);

      assert.equal(first.status, 200);
      assert.equal(second.status, 429);
      assert.equal(second.headers.get("retry-after"), "60");
    } finally {
      await new Promise<void>((resolve, reject) => {
        server.close((error) => error ? reject(error) : resolve());
      });
    }
  });

  test("works in an actual Hono app", async () => {
    const app = new Hono();
    app.use("*", createHonoRateLimiter({ limit: 1, now: () => 1_000 }));
    app.get("/limited", (c) => c.json({ ok: true }));

    const first = await app.request("http://localhost/limited", {
      headers: { "x-forwarded-for": "203.0.113.20" },
    });
    const second = await app.request("http://localhost/limited", {
      headers: { "x-forwarded-for": "203.0.113.20" },
    });

    assert.equal(first.status, 200);
    assert.equal(second.status, 429);
    assert.equal(second.headers.get("retry-after"), "60");
  });
});

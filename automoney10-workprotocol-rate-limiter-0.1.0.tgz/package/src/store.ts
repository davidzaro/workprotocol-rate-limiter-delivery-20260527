import type { RateLimitStore, RedisLikeClient } from "./types.js";

interface MemoryEntry {
  value: unknown;
  expiresAt: number;
}

export class MemoryStore implements RateLimitStore {
  private readonly values = new Map<string, MemoryEntry>();
  private readonly now: () => number;

  constructor(now: () => number = () => Date.now()) {
    this.now = now;
  }

  async get<T>(key: string): Promise<T | undefined> {
    const entry = this.values.get(key);
    if (!entry) {
      return undefined;
    }
    if (entry.expiresAt <= this.now()) {
      this.values.delete(key);
      return undefined;
    }
    return entry.value as T;
  }

  async set<T>(key: string, value: T, ttlMs: number): Promise<void> {
    this.values.set(key, {
      value,
      expiresAt: this.now() + Math.max(1, ttlMs),
    });
  }

  async delete(key: string): Promise<void> {
    this.values.delete(key);
  }
}

export class RedisStore implements RateLimitStore {
  private readonly client: RedisLikeClient;

  constructor(client: RedisLikeClient) {
    this.client = client;
  }

  async get<T>(key: string): Promise<T | undefined> {
    const raw = await this.client.get(key);
    if (!raw) {
      return undefined;
    }
    return JSON.parse(raw) as T;
  }

  async set<T>(key: string, value: T, ttlMs: number): Promise<void> {
    await this.client.set(key, JSON.stringify(value), "PX", Math.max(1, ttlMs));
  }

  async delete(key: string): Promise<void> {
    await this.client.del?.(key);
  }
}

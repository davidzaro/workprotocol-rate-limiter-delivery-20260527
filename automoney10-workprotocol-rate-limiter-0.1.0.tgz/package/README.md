# WorkProtocol Rate Limiter

Configurable TypeScript rate limiter middleware for Express and Hono. It ships
with fixed-window, sliding-window, and token-bucket strategies, plus in-memory
and Redis-compatible storage.

## Install

```bash
npm install @automoney10/workprotocol-rate-limiter
```

Redis support accepts an `ioredis`-compatible client. Express, Hono, and ioredis
are optional peer dependencies so the package can be used in either framework
without pulling in the other.

## Express

```ts
import express from "express";
import { createExpressRateLimiter } from "@automoney10/workprotocol-rate-limiter";

const app = express();

app.use(createExpressRateLimiter({
  limit: 100,
  windowMs: 60_000,
  strategy: "fixed-window",
}));
```

Blocked requests receive `429` plus:

- `Retry-After`
- `X-RateLimit-Limit`
- `X-RateLimit-Remaining`
- `X-RateLimit-Reset`

## Hono

```ts
import { Hono } from "hono";
import { createHonoRateLimiter } from "@automoney10/workprotocol-rate-limiter";

const app = new Hono();

app.use("*", createHonoRateLimiter({
  limit: 100,
  windowMs: 60_000,
  strategy: "sliding-window",
}));
```

## Token Bucket

```ts
import { createExpressRateLimiter } from "@automoney10/workprotocol-rate-limiter";

app.use(createExpressRateLimiter({
  strategy: "token-bucket",
  capacity: 30,
  refillRatePerSecond: 2,
  windowMs: 60_000,
}));
```

## Redis Backend

```ts
import Redis from "ioredis";
import { createHonoRateLimiter } from "@automoney10/workprotocol-rate-limiter";

const redis = new Redis(process.env.REDIS_URL);

app.use("*", createHonoRateLimiter({
  redis,
  keyPrefix: "api-rate-limit",
  limit: 100,
  windowMs: 60_000,
}));
```

If `redis` is omitted, the middleware automatically falls back to an in-memory
store. For horizontally scaled production deployments, pass a Redis client.

## Per-Route Configuration

Route rules can be exact path prefixes, regular expressions, or predicates.

```ts
app.use(createExpressRateLimiter({
  limit: 100,
  windowMs: 60_000,
  routes: [
    { path: "/login", limit: 5, windowMs: 60_000, strategy: "sliding-window" },
    { path: /^\/api\/v2/, limit: 250, windowMs: 60_000 },
    { path: (req) => req.method === "POST", limit: 20, strategy: "token-bucket" },
  ],
}));
```

## Custom Keys

By default, the limiter uses the first `x-forwarded-for` value, then `req.ip`,
then `anonymous`. Override it when you need API-key or user-id based limits.

```ts
createExpressRateLimiter({
  keyGenerator: (req) => String(req.headers?.["x-api-key"] ?? req.ip ?? "anonymous"),
});
```

## Development

```bash
npm install
npm test
npm run build
npm pack --dry-run
```

The test suite covers all three strategies, memory and Redis-compatible stores,
route overrides, headers, Express behavior, and Hono behavior.

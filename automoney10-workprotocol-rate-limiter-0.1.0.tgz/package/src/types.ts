export type RateLimitStrategy = "fixed-window" | "sliding-window" | "token-bucket";

export interface RateLimitRequest {
  ip?: string;
  path?: string;
  method?: string;
  headers?: Record<string, string | string[] | undefined>;
}

export interface RateLimitResult {
  allowed: boolean;
  limit: number;
  remaining: number;
  resetTime: number;
  retryAfterSeconds: number;
  strategy: RateLimitStrategy;
  key: string;
  headers: Record<string, string>;
}

export interface RateLimitRule {
  limit?: number;
  windowMs?: number;
  strategy?: RateLimitStrategy;
  capacity?: number;
  refillRatePerSecond?: number;
  keyPrefix?: string;
}

export interface RouteRule extends RateLimitRule {
  path: string | RegExp | ((request: RateLimitRequest) => boolean);
}

export type KeyGenerator = (request: RateLimitRequest) => string;

export interface RateLimiterOptions extends RateLimitRule {
  routes?: RouteRule[];
  store?: RateLimitStore;
  redis?: RedisLikeClient;
  keyGenerator?: KeyGenerator;
  now?: () => number;
}

export interface RateLimitStore {
  get<T>(key: string): Promise<T | undefined>;
  set<T>(key: string, value: T, ttlMs: number): Promise<void>;
  delete?(key: string): Promise<void>;
}

export interface RedisLikeClient {
  get(key: string): Promise<string | null> | string | null;
  set(key: string, value: string, mode: "PX", ttlMs: number): Promise<unknown> | unknown;
  del?(key: string): Promise<unknown> | unknown;
}

import type { RateLimitResult, RateLimitRule, RateLimitStore, RateLimitStrategy } from "./types.js";

interface FixedWindowState {
  windowStart: number;
  count: number;
}

interface SlidingWindowState {
  hits: number[];
}

interface TokenBucketState {
  tokens: number;
  lastRefill: number;
}

interface NormalizedRule {
  limit: number;
  windowMs: number;
  strategy: RateLimitStrategy;
  capacity: number;
  refillRatePerSecond: number;
  keyPrefix: string;
}

export function normalizeRule(rule: RateLimitRule = {}): NormalizedRule {
  const limit = Math.max(1, Math.floor(rule.limit ?? 100));
  const windowMs = Math.max(100, Math.floor(rule.windowMs ?? 60_000));
  const capacity = Math.max(1, Math.floor(rule.capacity ?? limit));
  return {
    limit,
    windowMs,
    strategy: rule.strategy ?? "fixed-window",
    capacity,
    refillRatePerSecond: Math.max(0.001, rule.refillRatePerSecond ?? capacity / (windowMs / 1000)),
    keyPrefix: rule.keyPrefix ?? "rate-limit",
  };
}

export async function applyStrategy(
  store: RateLimitStore,
  key: string,
  rule: RateLimitRule,
  now: number,
): Promise<RateLimitResult> {
  const normalized = normalizeRule(rule);
  if (normalized.strategy === "fixed-window") {
    return fixedWindow(store, key, normalized, now);
  }
  if (normalized.strategy === "sliding-window") {
    return slidingWindow(store, key, normalized, now);
  }
  return tokenBucket(store, key, normalized, now);
}

async function fixedWindow(
  store: RateLimitStore,
  key: string,
  rule: NormalizedRule,
  now: number,
): Promise<RateLimitResult> {
  const state = (await store.get<FixedWindowState>(key)) ?? { windowStart: now, count: 0 };
  const active = now - state.windowStart < rule.windowMs ? state : { windowStart: now, count: 0 };
  const nextCount = active.count + 1;
  const allowed = nextCount <= rule.limit;
  const nextState = { windowStart: active.windowStart, count: allowed ? nextCount : active.count };
  const resetTime = active.windowStart + rule.windowMs;
  await store.set(key, nextState, resetTime - now);
  return buildResult({
    allowed,
    limit: rule.limit,
    remaining: Math.max(0, rule.limit - nextState.count),
    resetTime,
    retryAfterMs: allowed ? 0 : resetTime - now,
    strategy: rule.strategy,
    key,
  });
}

async function slidingWindow(
  store: RateLimitStore,
  key: string,
  rule: NormalizedRule,
  now: number,
): Promise<RateLimitResult> {
  const state = (await store.get<SlidingWindowState>(key)) ?? { hits: [] };
  const cutoff = now - rule.windowMs;
  const hits = state.hits.filter((item) => item > cutoff);
  const allowed = hits.length < rule.limit;
  if (allowed) {
    hits.push(now);
  }
  const resetTime = hits.length > 0 ? hits[0]! + rule.windowMs : now + rule.windowMs;
  await store.set(key, { hits }, Math.max(rule.windowMs, resetTime - now));
  return buildResult({
    allowed,
    limit: rule.limit,
    remaining: Math.max(0, rule.limit - hits.length),
    resetTime,
    retryAfterMs: allowed ? 0 : resetTime - now,
    strategy: rule.strategy,
    key,
  });
}

async function tokenBucket(
  store: RateLimitStore,
  key: string,
  rule: NormalizedRule,
  now: number,
): Promise<RateLimitResult> {
  const state = (await store.get<TokenBucketState>(key)) ?? {
    tokens: rule.capacity,
    lastRefill: now,
  };
  const elapsedSeconds = Math.max(0, (now - state.lastRefill) / 1000);
  const refilled = Math.min(rule.capacity, state.tokens + elapsedSeconds * rule.refillRatePerSecond);
  const allowed = refilled >= 1;
  const tokens = allowed ? refilled - 1 : refilled;
  const retryAfterMs = allowed ? 0 : ((1 - tokens) / rule.refillRatePerSecond) * 1000;
  const resetTime = allowed ? now : now + retryAfterMs;
  await store.set(key, { tokens, lastRefill: now }, rule.windowMs);
  return buildResult({
    allowed,
    limit: rule.capacity,
    remaining: Math.max(0, Math.floor(tokens)),
    resetTime,
    retryAfterMs,
    strategy: rule.strategy,
    key,
  });
}

function buildResult(input: {
  allowed: boolean;
  limit: number;
  remaining: number;
  resetTime: number;
  retryAfterMs: number;
  strategy: RateLimitStrategy;
  key: string;
}): RateLimitResult {
  const retryAfterSeconds = Math.max(0, Math.ceil(input.retryAfterMs / 1000));
  const headers: Record<string, string> = {
    "X-RateLimit-Limit": String(input.limit),
    "X-RateLimit-Remaining": String(input.remaining),
    "X-RateLimit-Reset": String(Math.ceil(input.resetTime / 1000)),
  };
  if (!input.allowed) {
    headers["Retry-After"] = String(Math.max(1, retryAfterSeconds));
  }
  return {
    allowed: input.allowed,
    limit: input.limit,
    remaining: input.remaining,
    resetTime: input.resetTime,
    retryAfterSeconds,
    strategy: input.strategy,
    key: input.key,
    headers,
  };
}

import { createRateLimiterCore } from "./core.js";
import type { RateLimiterOptions, RateLimitRequest } from "./types.js";
import type { RequestHandler } from "express";

type ExpressNext = () => void;
type ExpressMiddleware = RequestHandler &
  ((req: ExpressLikeRequest, res: ExpressLikeResponse, next: ExpressNext) => Promise<void>);

interface ExpressLikeRequest {
  ip?: string;
  path?: string;
  url?: string;
  method?: string;
  headers?: Record<string, string | string[] | undefined>;
}

interface ExpressLikeResponse {
  statusCode?: number;
  setHeader?(name: string, value: string): void;
  header?(name: string, value: string): void;
  status?(statusCode: number): ExpressLikeResponse;
  json?(body: unknown): unknown;
  send?(body: unknown): unknown;
  end?(body?: unknown): unknown;
}

export function createExpressRateLimiter(options: RateLimiterOptions = {}): ExpressMiddleware {
  const limiter = createRateLimiterCore(options);
  const rateLimitExpress = async function rateLimitExpress(
    req: ExpressLikeRequest,
    res: ExpressLikeResponse,
    next: ExpressNext,
  ): Promise<void> {
    const result = await limiter.check(toRateLimitRequest(req));
    for (const [name, value] of Object.entries(result.headers)) {
      if (res.setHeader) {
        res.setHeader(name, value);
      } else if (res.header) {
        res.header(name, value);
      }
    }
    if (result.allowed) {
      next();
      return;
    }
    if (res.status) {
      res.status(429);
    } else {
      res.statusCode = 429;
    }
    const body = { error: "Too Many Requests", retryAfterSeconds: result.retryAfterSeconds };
    if (res.json) {
      res.json(body);
      return;
    }
    if (res.send) {
      res.send(body);
      return;
    }
    res.end?.(JSON.stringify(body));
  };
  return rateLimitExpress as ExpressMiddleware;
}

function toRateLimitRequest(req: ExpressLikeRequest): RateLimitRequest {
  const request: RateLimitRequest = {
    path: req.path ?? req.url?.split("?")[0] ?? "/",
  };
  if (req.ip !== undefined) {
    request.ip = req.ip;
  }
  if (req.method !== undefined) {
    request.method = req.method;
  }
  if (req.headers !== undefined) {
    request.headers = req.headers;
  }
  return request;
}

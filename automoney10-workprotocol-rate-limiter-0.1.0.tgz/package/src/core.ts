import { applyStrategy, normalizeRule } from "./strategies.js";
import { MemoryStore, RedisStore } from "./store.js";
import type { RateLimiterOptions, RateLimitRequest, RateLimitResult, RateLimitRule, RouteRule } from "./types.js";

export interface RateLimiterCore {
  check(request: RateLimitRequest): Promise<RateLimitResult>;
}

export function createRateLimiterCore(options: RateLimiterOptions = {}): RateLimiterCore {
  const now = options.now ?? (() => Date.now());
  const store = options.store ?? (options.redis ? new RedisStore(options.redis) : new MemoryStore(now));
  const keyGenerator = options.keyGenerator ?? defaultKeyGenerator;

  return {
    async check(request: RateLimitRequest): Promise<RateLimitResult> {
      const rule = resolveRule(options, request);
      const normalized = normalizeRule(rule);
      const key = [
        normalized.keyPrefix,
        normalized.strategy,
        routeIdentity(rule),
        keyGenerator(request),
      ].join(":");
      return applyStrategy(store, key, rule, now());
    },
  };
}

export function defaultKeyGenerator(request: RateLimitRequest): string {
  const forwarded = headerValue(request.headers, "x-forwarded-for");
  const firstForwarded = forwarded?.split(",")[0]?.trim();
  return firstForwarded || request.ip || "anonymous";
}

export function resolveRule(options: RateLimiterOptions, request: RateLimitRequest): RateLimitRule {
  const matched = options.routes?.find((route) => routeMatches(route, request));
  const rule: RateLimitRule = {};
  assignIfDefined(rule, "limit", matched?.limit ?? options.limit);
  assignIfDefined(rule, "windowMs", matched?.windowMs ?? options.windowMs);
  assignIfDefined(rule, "strategy", matched?.strategy ?? options.strategy);
  assignIfDefined(rule, "capacity", matched?.capacity ?? options.capacity);
  assignIfDefined(rule, "refillRatePerSecond", matched?.refillRatePerSecond ?? options.refillRatePerSecond);
  assignIfDefined(rule, "keyPrefix", matched?.keyPrefix ?? options.keyPrefix);
  return rule;
}

export function headersFromResult(result: RateLimitResult): Record<string, string> {
  return { ...result.headers };
}

function routeMatches(route: RouteRule, request: RateLimitRequest): boolean {
  if (typeof route.path === "function") {
    return route.path(request);
  }
  const path = request.path ?? "/";
  if (route.path instanceof RegExp) {
    return route.path.test(path);
  }
  return path === route.path || path.startsWith(`${route.path}/`);
}

function routeIdentity(rule: RateLimitRule): string {
  return `${rule.limit ?? "default"}:${rule.windowMs ?? "default"}:${rule.keyPrefix ?? "default"}`;
}

function headerValue(headers: RateLimitRequest["headers"], name: string): string | undefined {
  if (!headers) {
    return undefined;
  }
  const lower = name.toLowerCase();
  for (const [key, value] of Object.entries(headers)) {
    if (key.toLowerCase() !== lower) {
      continue;
    }
    return Array.isArray(value) ? value[0] : value;
  }
  return undefined;
}

function assignIfDefined<K extends keyof RateLimitRule>(rule: RateLimitRule, key: K, value: RateLimitRule[K] | undefined): void {
  if (value !== undefined) {
    rule[key] = value;
  }
}

import { createRateLimiterCore } from "./core.js";
import type { RateLimiterOptions, RateLimitRequest } from "./types.js";

type HonoNext = () => Promise<void> | void;

interface HonoLikeContext {
  req: {
    path?: string;
    url?: string;
    method?: string;
    header?(name: string): string | undefined;
  };
  header?(name: string, value: string): void;
  json?(body: unknown, status?: number): unknown;
  get?(name: string): unknown;
}

export function createHonoRateLimiter(options: RateLimiterOptions = {}) {
  const limiter = createRateLimiterCore(options);
  return async function rateLimitHono(c: HonoLikeContext, next: HonoNext) {
    const result = await limiter.check(toRateLimitRequest(c));
    for (const [name, value] of Object.entries(result.headers)) {
      c.header?.(name, value);
    }
    if (result.allowed) {
      await next();
      return;
    }
    const body = { error: "Too Many Requests", retryAfterSeconds: result.retryAfterSeconds };
    if (c.json) {
      return c.json(body, 429);
    }
    return { status: 429, body };
  };
}

function toRateLimitRequest(c: HonoLikeContext): RateLimitRequest {
  const forwarded = c.req.header?.("x-forwarded-for");
  const realIp = c.req.header?.("x-real-ip");
  const contextIp = c.get?.("ip");
  const request: RateLimitRequest = {
    path: c.req.path ?? pathFromUrl(c.req.url) ?? "/",
  };
  const ip = typeof contextIp === "string" ? contextIp : realIp ?? forwarded;
  if (ip !== undefined) {
    request.ip = ip;
  }
  if (c.req.method !== undefined) {
    request.method = c.req.method;
  }
  const headers: Record<string, string | undefined> = {};
  if (forwarded !== undefined) {
    headers["x-forwarded-for"] = forwarded;
  }
  if (realIp !== undefined) {
    headers["x-real-ip"] = realIp;
  }
  if (Object.keys(headers).length > 0) {
    request.headers = headers;
  }
  return request;
}

function pathFromUrl(url?: string): string | undefined {
  if (!url) {
    return undefined;
  }
  try {
    return new URL(url).pathname;
  } catch {
    return url.split("?")[0];
  }
}
